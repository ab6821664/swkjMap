package com.swkj.mapdisplay.utils.utilsImpl;

import java.text.SimpleDateFormat;

/*
   @
 */
public interface Constants {
       //用户名
       String SESSION_USER="SESSION_USER";
       //设置用户的权限
       String AUTHORITY="admin";
       //界牌界碑信息id信息
       String BHQ_BOUNDA="BHQ_Bounda";
       //界牌界碑信息AsHeader信息
       String ASHEADER="N";
       //牌栏BHQ_Brand的信息
       String BHQ_BRAND="BHQ_Brand";
       SimpleDateFormat SIMPLE_DATE_FORMAT=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
       //人类活动下拉框的key值
       String XhPEOPLEACTION="XhPeopleAction";
}

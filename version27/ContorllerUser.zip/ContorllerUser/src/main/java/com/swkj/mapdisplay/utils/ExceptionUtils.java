/*package com.swkj.mapdisplay.utils;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class ExceptionUtils {
        //将所有的错误页面拦截下来
        @ExceptionHandler(value = Exception.class)
        @ResponseBody
        public Object exception(){
            return "您访问的页面正忙!";
        }
     *//*   //将404页面拦截下来
        public Enbe containerCustomizer(){
            return new ;
        }*//*
}*/

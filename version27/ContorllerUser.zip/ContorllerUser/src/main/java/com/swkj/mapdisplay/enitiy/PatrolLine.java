package com.swkj.mapdisplay.enitiy;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
public class PatrolLine {
        private String PatrolLineId;
        private String UserId;
        private String ImagePath;
        private float Length;
        private String LineName;
        private String RoleID;



}

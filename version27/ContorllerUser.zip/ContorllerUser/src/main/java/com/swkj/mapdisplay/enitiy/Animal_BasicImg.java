package com.swkj.mapdisplay.enitiy;

import lombok.Getter;
import lombok.Setter;

/*
  @动物图片表
 */
@Getter
@Setter
public class Animal_BasicImg {
        private String BioImageId;
        private String ImageAddress;
        private String ImageData;
        private String NativeCode;
        private Integer MediaType;
        private String ImageId;
}

package com.swkj.mapdisplay.enitiy;

import lombok.Getter;
import lombok.Setter;

/*
  @植物图片信息表
 */
@Getter
@Setter
public class BoatImg {
        private Integer ISID;
        private String BoatImgId;
        private String BoatImgAddress;
        private String ImgType;
}
